from setuptools import setup 

setup(name = 'Geometry',
version = '0.1',
description = 'some geometric figures',
packages = ['Geometry'],
author = 'João Emanuel',
author_email= 'joaobeza9@gmail.com',
zip_safe = False)